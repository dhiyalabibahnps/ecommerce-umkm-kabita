# KABITA E-COMMERCE — AI RULES
Skripsi • Waterfall (UI-first, API later) • Be concise: no praise, no summaries, code-first answers.

## STACK (fixed, never suggest alternatives)
Vue 3 `<script setup lang="ts">` • PrimeVue v4 • Pinia • Vue Router • Axios • Vite • PrimeFlex
TS strict: no `any`, no `@ts-ignore`, no unused imports.

## FOLDER MAP (use exactly)
components/layout/ → AppHeader, AppFooter, AppSidebar
components/ui/     → BaseDialog, BaseCard, ProductCard, EmptyState
components/{auth,home,product,dashboard}/ → feature parts
views/ stores/ types/ services/ composables/ utils/ router/

## BIG-REUSABLE POLICY
Few big reusable components > many tiny ones.
Every page composes: AppHeader + <main> + AppFooter (+ AppSidebar / BaseDialog when needed).

## LANGUAGE
Code/vars/comments: English • UI text/labels/buttons/messages: Indonesian • Explanations to user: Indonesian.

## DESIGN CONSISTENCY
- UI = PrimeVue only (Button, InputText, FloatLabel, Password, Card, Tag, Dialog, Drawer, DataTable, Toast, Menu).
- No raw <button>/<input>/<table>; no Tailwind/Bootstrap/custom frameworks.
- Spacing/layout = PrimeFlex classes (flex, gap-2, mt-3, align-items-center…).
- Icons = `pi pi-*` classes only.
- Money → formatRupiah(); dates → formatTanggal() from utils/format.ts.
- Status→Tag: active=success • pending*=warn • rejected|banned=danger • draft=secondary.

## ANTI-HALLUCINATION
- Imports only from: vue, pinia, vue-router, primevue/*, @/…
- PrimeVue v4 names: Drawer (NOT Sidebar), ToggleSwitch (NOT InputSwitch), lowercase paths (`primevue/button`).
- Never reference files/stores/types not in FOLDER MAP or not yet created; if unsure → ask.
- Never invent PrimeVue props; use common ones only (label, icon, severity, modelValue, placeholder).

## BEGINNER-FRIENDLY CODE
Short functions, obvious names, 1-line comment on tricky logic.
Props/emits typed: defineProps<{…}>() / defineEmits<{…}>().
Stores: state+getters+actions, inline MOCK data, real call commented `// TODO(api): axios…`.
File >150 lines → split. No clever one-liners.

## ERD (truth for src/types)
users(id,name,email,role:'buyer'|'seller'|'admin',status)
shops(id,seller_id,name,slug,logo,status)
categories(id,name,slug)
products(id,shop_id,category_id,name,slug,price,cost_price,stock,status)
orders(id,order_number,buyer_id,shop_id,subtotal,shipping_cost,total_amount,shipping_method,payment_method,status)
order_items(id,order_id,product_id,quantity,price_snapshot,cost_snapshot)
daily_product_sales(id,date,product_id,shop_id,category_id,total_qty_sold,total_revenue,total_profit)