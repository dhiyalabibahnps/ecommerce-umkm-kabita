<script setup lang="ts">
import type { CartGroupByShop, CartItem } from '@/types'
import Button from 'primevue/button'
import Checkbox from 'primevue/checkbox'
import { computed, ref } from 'vue'

// --- MOCK DATA BERDASARKAN ENTITY INTERFACES ---
const cartGroups = ref<CartGroupByShop[]>([
  {
    shop_id: 1,
    shop_name: 'Kopi Kenangan Senja',
    subtotal: '85000',
    items: [
      {
        id: 101,
        cart_id: 1,
        product_id: 1,
        quantity: 2,
        subtotal: '170000',
        created_at: null,
        updated_at: null,
        shop: {
          id: 1,
          name: 'Kopi Kenangan Senja',
          slug: 'kopi-kenangan-senja',
          logo: null
        },
        product: {
          id: 1,
          shop_id: 1,
          category_id: 1,
          name: 'Kopi Arabica Gayo Premium Blend 250g',
          slug: 'kopi-arabica-gayo-premium-blend-250g',
          description: null,
          price: '85000',
          cost_price: null,
          stock: 10,
          weight: 250,
          status: 'active',
          verified_at: null,
          rejection_reason: null,
          created_at: '',
          images: [
            { id: 1, url: 'https://primefaces.org/cdn/primevue/images/galleria/galleria1.jpg' }
          ]
        }
      }
    ]
  },
  {
    shop_id: 2,
    shop_name: 'Kerajinan Tangan Ibu',
    subtotal: '165000',
    items: [
      {
        id: 102,
        cart_id: 1,
        product_id: 2,
        quantity: 1,
        subtotal: '120000',
        created_at: null,
        updated_at: null,
        shop: {
          id: 2,
          name: 'Kerajinan Tangan Ibu',
          slug: 'kerajinan-tangan-ibu',
          logo: null
        },
        product: {
          id: 2,
          shop_id: 2,
          category_id: 2,
          name: 'Keranjang Anyaman Rotan Serbaguna',
          slug: 'keranjang-anyaman-rotan-serbaguna',
          description: null,
          price: '120000',
          cost_price: null,
          stock: 5,
          weight: 500,
          status: 'active',
          verified_at: null,
          rejection_reason: null,
          created_at: '',
          images: [
            { id: 2, url: 'https://primefaces.org/cdn/primevue/images/galleria/galleria2.jpg' }
          ]
        }
      },
      {
        id: 103,
        cart_id: 1,
        product_id: 3,
        quantity: 1,
        subtotal: '45000',
        created_at: null,
        updated_at: null,
        shop: {
          id: 2,
          name: 'Kerajinan Tangan Ibu',
          slug: 'kerajinan-tangan-ibu',
          logo: null
        },
        product: {
          id: 3,
          shop_id: 2,
          category_id: 2,
          name: 'Tatakan Gelas Kayu Jati Solid (Set of 4)',
          slug: 'tatakan-gelas-kayu-jati-solid-set-of-4',
          description: null,
          price: '45000',
          cost_price: null,
          stock: 12,
          weight: 300,
          status: 'active',
          verified_at: null,
          rejection_reason: null,
          created_at: '',
          images: [
            { id: 3, url: 'https://primefaces.org/cdn/primevue/images/galleria/galleria3.jpg' }
          ]
        }
      }
    ]
  }
])

// Flat list dari seluruh item untuk kalkulasi mudah
const allItems = computed<CartItem[]>(() => {
  return cartGroups.value.flatMap((group) => group.items)
})

// --- SELECTION STATES ---
const selectedItemIds = ref<number[]>([101, 102, 103])

// Status Pilih Semua (Checkbox Atas)
const isSelectAll = computed({
  get: () => allItems.value.length > 0 && selectedItemIds.value.length === allItems.value.length,
  set: (val: boolean) => {
    if (val) {
      selectedItemIds.value = allItems.value.map((item) => item.id)
    } else {
      selectedItemIds.value = []
    }
  }
})

// Cek apakah seluruh item di satu toko terpilih
const isShopSelected = (group: CartGroupByShop) => {
  return group.items.every((item) => selectedItemIds.value.includes(item.id))
}

// Toggle Checkbox Toko
const toggleShopSelection = (group: CartGroupByShop, checked: boolean) => {
  const shopItemIds = group.items.map((item) => item.id)
  if (checked) {
    selectedItemIds.value = Array.from(new Set([...selectedItemIds.value, ...shopItemIds]))
  } else {
    selectedItemIds.value = selectedItemIds.value.filter((id) => shopItemIds!.includes(id))
  }
}

// Toggle Checkbox Item Tunggal
const toggleItemSelection = (id: number, checked: boolean) => {
  if (checked) {
    selectedItemIds.value.push(id)
  } else {
    selectedItemIds.value = selectedItemIds.value.filter((itemId) => itemId !== id)
  }
}

// --- AKSI KUANTITAS & HAPUS ---
const updateQuantity = (item: CartItem, delta: number) => {
  const newQty = item.quantity + delta
  if (newQty >= 1 && newQty <= (item.product?.stock || 99)) {
    item.quantity = newQty
  }
}

const deleteItem = (itemId: number) => {
  cartGroups.value.forEach((group) => {
    group.items = group.items.filter((i) => i.id !== itemId)
  })
  cartGroups.value = cartGroups.value.filter((g) => g.items.length > 0)
  selectedItemIds.value = selectedItemIds.value.filter((id) => id !== itemId)
}

const deleteSelectedItems = () => {
  selectedItemIds.value.forEach((id) => deleteItem(id))
}

// --- RINGKASAN BELANJA ---
const discountAmount = 10000 // Mock promo diskon

const totalSelectedCount = computed(() => {
  return allItems.value
    .filter((item) => selectedItemIds.value.includes(item.id))
    .reduce((sum, item) => sum + item.quantity, 0)
})

const subtotalAmount = computed(() => {
  return allItems.value
    .filter((item) => selectedItemIds.value.includes(item.id))
    .reduce((sum, item) => {
      const price = parseFloat(item.product?.price || '0')
      return sum + price * item.quantity
    }, 0)
})

const grandTotalAmount = computed(() => {
  if (subtotalAmount.value === 0) return 0
  return Math.max(0, subtotalAmount.value - discountAmount)
})

// Helper Currency
const formatCurrency = (val: number) => {
  return 'Rp ' + val.toLocaleString('id-ID')
}
</script>

<template>
  <div class="min-h-screen bg-slate-50 py-8 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto space-y-6">

      <--! Page Title -->
        <h1 class="text-xl font-bold text-slate-800">Keranjang Belanja</h1>

        <--! Main Layout Grid -->
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

            <--! KOLOM KIRI (Daftar Item & Toko) -->
              <div class="lg:col-span-8 space-y-4">

                <--! Card Header Select All -->
                  <div class="bg-white rounded p-4 shadow-sm border border-slate-100 flex items-center justify-between">
                    <div class="flex items-center gap-3">
                      <Checkbox v-model="isSelectAll" :binary="true" inputId="selectAll" />
                      <label for="selectAll" class="text-xs font-semibold text-slate-700 cursor-pointer">
                        Pilih Semua ({{ totalSelectedCount }} Item)
                      </label>
                    </div>
                    <button v-if="selectedItemIds.length > 0" @click="deleteSelectedItems"
                      class="text-xs text-rose-600 font-semibold hover:underline">
                      Hapus
                    </button>
                  </div>

                  <--! Group Per Toko -->
                    <div v-for="group in cartGroups" :key="group.shop_id"
                      class="bg-white rounded shadow-sm border border-slate-100 overflow-hidden">
                      <--! Header Toko -->
                        <div class="bg-slate-50/50 p-4 border-b border-slate-100 flex items-center justify-between">
                          <div class="flex items-center gap-3">
                            <Checkbox :modelValue="isShopSelected(group)" :binary="true"
                              @update:modelValue="(val) => toggleShopSelection(group, val)" />
                            <div class="flex items-center gap-2">
                              <i class="pi pi-shop text-slate-700 text-sm"></i>
                              <span class="text-xs font-bold text-slate-800">{{ group.shop_name }}</span>
                            </div>
                          </div>
                        </div>

                        <--! List Product Cart Item -->
                          <div class="divide-y divide-slate-100">
                            <div v-for="item in group.items" :key="item.id" class="p-4 flex items-start gap-3 sm:gap-4">
                              <--! Checkbox Item -->
                                <Checkbox :modelValue="selectedItemIds.includes(item.id)" :binary="true" class="mt-4"
                                  @update:modelValue="(val) => toggleItemSelection(item.id, val)" />

                                <--! Gambar Produk -->
                                  <img
                                    :src="item.product?.images?.[0]?.url || 'https://primefaces.org/cdn/primevue/images/galleria/galleria1.jpg'"
                                    :alt="item.product?.name"
                                    class="w-20 h-20 rounded object-cover border border-slate-100 shrink-0" />

                                  <--! Detail Produk & Kontrol Kuantitas -->
                                    <div class="flex-1 min-w-0 space-y-1">
                                      <div class="flex items-start justify-between gap-2">
                                        <div>
                                          <h3 class="text-xs font-bold text-slate-800 line-clamp-1">{{
                                            item.product?.name }}</h3>
                                          <p class="text-[11px] text-slate-400 mt-0.5">
                                            Varian: {{ item.product_id === 1 ? 'Medium Roast' : item.product_id === 2 ?
                                              'Ukuran L' :
                                            'Natural Finish' }}
                                          </p>
                                        </div>
                                        <--! Tombol Hapus Single Item -->
                                          <button @click="deleteItem(item.id)"
                                            class="text-slate-400 hover:text-rose-600 transition-colors">
                                            <i class="pi pi-trash text-xs"></i>
                                          </button>
                                      </div>

                                      <--! Harga & Quantity Selector -->
                                        <div class="flex flex-wrap items-center justify-between pt-2 gap-2">
                                          <span class="text-xs font-bold text-blue-600">
                                            {{ formatCurrency(parseFloat(item.product?.price || '0')) }}
                                          </span>

                                          <--! Plus Minus Quantity Counter -->
                                            <div
                                              class="flex items-center border border-slate-200 rounded-lg overflow-hidden bg-white">
                                              <button @click="updateQuantity(item, -1)" :disabled="item.quantity <= 1"
                                                class="px-2.5 py-1 text-slate-500 hover:bg-slate-50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                                                <i class="pi pi-minus text-[10px]"></i>
                                              </button>
                                              <span
                                                class="px-3 py-1 text-xs font-semibold text-slate-800 border-x border-slate-200 min-w-[32px] text-center">
                                                {{ item.quantity }}
                                              </span>
                                              <button @click="updateQuantity(item, 1)"
                                                class="px-2.5 py-1 text-slate-500 hover:bg-slate-50 transition-colors">
                                                <i class="pi pi-plus text-[10px]"></i>
                                              </button>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                          </div>

                    </div>

              </div>

              <--! KOLOM KANAN (Ringkasan Belanja) -->
                <div class="lg:col-span-4 space-y-4">
                  <div class="bg-white rounded p-6 shadow-sm border border-slate-100 space-y-4">
                    <h2 class="font-bold text-slate-800 text-sm">Ringkasan Belanja</h2>

                    <div class="space-y-2 text-xs border-b border-slate-100 pb-4">
                      <div class="flex items-center justify-between text-slate-600">
                        <span>Total Harga ({{ totalSelectedCount }} Barang)</span>
                        <span class="font-medium text-slate-800">{{ formatCurrency(subtotalAmount) }}</span>
                      </div>
                      <div v-if="subtotalAmount > 0" class="flex items-center justify-between text-red-600 font-medium">
                        <span>Total Diskon Barang</span>
                        <span>- {{ formatCurrency(discountAmount) }}</span>
                      </div>
                    </div>

                    <--! Total Harga Akhir -->
                      <div class="flex items-center justify-between pt-1">
                        <span class="text-xs font-bold text-slate-800">Total Harga</span>
                        <span class="text-lg font-bold text-blue-600">{{ formatCurrency(grandTotalAmount) }}</span>
                      </div>

                      <--! Tombol Beli / Checkout -->
                        <router-link to="/checkout">
                          <Button :label="`Beli (${totalSelectedCount})`" :disabled="totalSelectedCount === 0"
                            class="w-full bg-emerald-500! border-emerald-500! py-3! text-xs! font-bold! rounded! shadow-sm! hover:bg-emerald-600! disabled:opacity-50! disabled:cursor-not-allowed! mt-2" />
                        </router-link>
                  </div>
                </div>

          </div>

    </div>
  </div>
</template>