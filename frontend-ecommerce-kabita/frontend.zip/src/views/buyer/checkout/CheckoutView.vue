<script setup lang="ts">
import Button from 'primevue/button'
import Dialog from 'primevue/dialog'
import InputText from 'primevue/inputtext'
import ProgressSpinner from 'primevue/progressspinner'
import Select from 'primevue/select'
import Textarea from 'primevue/textarea'
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

// --- STATE LOADING SIMULASI API GET ---
const isLoadingPage = ref(true)

// --- STATE SIMULASI POST PESANAN ---
const isSubmittingOrder = ref(false)
const isSuccessModalOpen = ref(false)
const createdOrderData = ref({
  orderNumber: '',
  totalAmount: 0,
  paymentMethod: ''
})

// --- DATA STATE CHECKOUT ---
interface AddressItem {
  id: number
  name: string
  phone: string
  fullAddress: string
  isPrimary: boolean
}

const addresses = ref<AddressItem[]>([])
const selectedAddressId = ref<number>(1)

const activeAddress = computed(() => {
  return addresses.value.find((addr) => addr.id === selectedAddressId.value) || addresses.value[0]
})

// Modal / Dialog States Alamat
const isAddressModalOpen = ref(false)
const isAddNewFormOpen = ref(false)

const newAddress = ref({
  name: '',
  phone: '',
  fullAddress: ''
})

const selectAddress = (id: number) => {
  selectedAddressId.value = id
  isAddressModalOpen.value = false
}

const saveNewAddress = () => {
  if (!newAddress.value.name || !newAddress.value.phone || !newAddress.value.fullAddress) {
    alert('Harap isi semua kolom alamat!')
    return
  }

  const createdId = Date.now()
  addresses.value.push({
    id: createdId,
    name: newAddress.value.name,
    phone: newAddress.value.phone,
    fullAddress: newAddress.value.fullAddress,
    isPrimary: false
  })

  selectedAddressId.value = createdId
  newAddress.value = { name: '', phone: '', fullAddress: '' }
  isAddNewFormOpen.value = false
  isAddressModalOpen.value = false
}

// Data Pengiriman & Pesanan
const shippingOptions = [
  { label: 'Reguler (2-3 hari) - Rp 15.000', value: 'reguler_15' },
  { label: 'Reguler (2-3 hari) - Rp 20.000', value: 'reguler_20' },
  { label: 'Kargo (3-5 hari) - Rp 30.000', value: 'cargo_30' }
]

const orderGroups = ref<any[]>([])
const paymentInfo = ref({
  bankName: 'Bank BCA',
  accountNumber: '123 456 7890',
  accountHolder: 'PT Kabita Indonesia'
})

const isCopied = ref(false)

const copyAccountNumber = () => {
  navigator.clipboard.writeText(paymentInfo.value.accountNumber.replace(/\s/g, ''))
  isCopied.value = true
  setTimeout(() => (isCopied.value = false), 2000)
}

const formatCurrency = (val: number) => {
  return 'Rp ' + val.toLocaleString('id-ID')
}

// Total Calc
const totalItemsPrice = computed(() => {
  return orderGroups.value.reduce((sum, g) => sum + g.price * g.qty, 0)
})
const totalShippingCost = 35000
const serviceFee = 2500
const grandTotal = computed(() => totalItemsPrice.value + totalShippingCost + serviceFee)

// --- STATE & SIMULASI UPLOAD BUKTI TRANSFER ---
const fileInput = ref<HTMLInputElement | null>(null)
const previewImage = ref<string | null>(null)
const isUploading = ref(false)
const uploadProgress = ref(0)
const isSuccess = ref(false)

const triggerFileInput = () => {
  fileInput.value?.click()
}

const handleFileSelect = (event: Event) => {
  const target = event.target as HTMLInputElement
  if (target.files && target.files[0]) {
    processUpload(target.files[0])
  }
}

const handleDrop = (event: DragEvent) => {
  if (event.dataTransfer?.files && event.dataTransfer.files[0]) {
    processUpload(event.dataTransfer.files[0])
  }
}

const processUpload = (file: File) => {
  if (!file.type.startsWith('image/')) {
    alert('Harap unggah file gambar (.PNG, .JPG, .JPEG)')
    return
  }

  const reader = new FileReader()
  reader.onload = (e) => {
    previewImage.value = e.target?.result as string
  }
  reader.readAsDataURL(file)

  isUploading.value = true
  isSuccess.value = false
  uploadProgress.value = 0

  const interval = setInterval(() => {
    uploadProgress.value += 20
    if (uploadProgress.value >= 100) {
      clearInterval(interval)
      isUploading.value = false
      isSuccess.value = true
    }
  }, 200)
}

const removeImage = () => {
  previewImage.value = null
  isSuccess.value = false
  uploadProgress.value = 0
  if (fileInput.value) {
    fileInput.value.value = ''
  }
}

// --- SIMULASI GET DATA DARI API ---
const fetchCheckoutData = () => {
  isLoadingPage.value = true
  setTimeout(() => {
    addresses.value = [
      {
        id: 1,
        name: 'Budi Santoso',
        phone: '0812-3456-7890',
        fullAddress: 'Jl. Sudirman No. 45, Komplek Mawar Indah Blok B2, Kebayoran Baru, Jakarta Selatan, DKI Jakarta 12190',
        isPrimary: true
      },
      {
        id: 2,
        name: 'Budi Santoso (Kantor)',
        phone: '0898-7654-3210',
        fullAddress: 'Gedung Wisma Millenia Lt. 4, Jl. MT Haryono, Pancoran, Jakarta Selatan, DKI Jakarta 12810',
        isPrimary: false
      }
    ]

    orderGroups.value = [
      {
        storeName: 'Toko Kopi Lokal',
        productName: 'Biji Kopi Arabika Gayo - 250g',
        variant: 'Medium Roast',
        price: 85000,
        qty: 1,
        image: 'https://primefaces.org/cdn/primevue/images/galleria/galleria1.jpg',
        selectedShipping: 'reguler_15'
      },
      {
        storeName: 'Kerajinan Tangan Jabar',
        productName: 'Keranjang Anyaman Rotan Premium',
        variant: 'Ukuran: Sedang',
        price: 45000,
        qty: 2,
        image: 'https://primefaces.org/cdn/primevue/images/galleria/galleria2.jpg',
        selectedShipping: 'reguler_20'
      }
    ]

    isLoadingPage.value = false
  }, 1000)
}

// --- SIMULASI POST PESANAN KE API ---
const handleCreateOrder = () => {
  isSubmittingOrder.value = true

  const payload = {
    address_id: selectedAddressId.value,
    items: orderGroups.value,
    payment_method: 'transfer_manual',
    proof_image: previewImage.value,
    total_amount: grandTotal.value
  }

  console.log('[POST API Payload]:', payload)

  setTimeout(() => {
    isSubmittingOrder.value = false

    createdOrderData.value = {
      orderNumber: `#KBTA-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}`,
      totalAmount: grandTotal.value,
      paymentMethod: 'Transfer Bank Manual'
    }

    isSuccessModalOpen.value = true
  }, 1500)
}

const navigateToOrders = () => {
  isSuccessModalOpen.value = false
  router.push('/profile/orders')
}

const navigateToHome = () => {
  isSuccessModalOpen.value = false
  router.push('/')
}

onMounted(() => {
  fetchCheckoutData()
})
</script>

<template>
  <div class="min-h-screen bg-slate-50 py-6 px-4 sm:px-6 lg:px-8">

    <!-- LOADING SPINNER MINGGIR / BULAT UTAMA -->
    <div v-if="isLoadingPage" class="min-h-[70vh] flex flex-col items-center justify-center gap-3">
      <ProgressSpinner style="width: 48px; height: 48px" strokeWidth="4" animationDuration=".8s" />
      <span class="text-xs text-slate-500 font-medium">Memuat Data Checkout...</span>
    </div>

    <!-- KONTEN UTAMA DITAMPILKAN SETELAH LOADING -->
    <div v-else class="max-w-7xl mx-auto space-y-6">

      <!-- Top Bar Navigation -->
      <div class="flex items-center justify-between text-xs text-slate-600">
        <router-link to="/cart" class="flex items-center gap-2 hover:text-blue-600 transition-colors font-medium">
          <i class="pi pi-arrow-left text-xs"></i>
          <span>Kembali</span>
        </router-link>
        <div class="flex items-center gap-1.5 text-slate-500 font-medium">
          <i class="pi pi-lock text-xs"></i>
          <span>Checkout Keamanan SSL</span>
        </div>
      </div>

      <!-- Main Layout Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

        <!-- KOLOM KIRI (Alamat + Ringkasan Pesanan) -->
        <div class="lg:col-span-7 space-y-6">

          <!-- Section 1: Alamat Pengiriman -->
          <div class="bg-white rounded p-6 shadow-sm border border-slate-100">
            <div class="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
              <div class="flex items-center gap-2 font-bold text-slate-800 text-sm">
                <i class="pi pi-map-marker text-blue-600"></i>
                <h2>Alamat Pengiriman</h2>
              </div>
              <button @click="isAddressModalOpen = true" class="text-xs text-blue-600 font-semibold hover:underline">
                Ubah Alamat
              </button>
            </div>

            <!-- Display Alamat Aktif -->
            <div class="space-y-1 text-xs text-slate-600">
              <p class="font-bold text-slate-800 text-sm">{{ activeAddress?.name }}</p>
              <p class="text-slate-500">{{ activeAddress?.phone }}</p>
              <p class="leading-relaxed mt-2 text-slate-600">{{ activeAddress?.fullAddress }}</p>
            </div>
          </div>

          <!-- Section 2: Ringkasan Pesanan -->
          <div class="bg-white rounded p-6 shadow-sm border border-slate-100 space-y-6">
            <div class="flex items-center gap-2 font-bold text-slate-800 text-sm pb-4 border-b border-slate-100">
              <i class="pi pi-shopping-bag text-blue-600"></i>
              <h2>Ringkasan Pesanan</h2>
            </div>

            <!-- List Toko & Barang -->
            <div v-for="(group, idx) in orderGroups" :key="idx"
              class="space-y-4 pb-6 border-b border-slate-100 last:border-0 last:pb-0">
              <div class="flex items-center gap-2 text-xs font-bold text-slate-700">
                <i class="pi pi-shop text-slate-400"></i>
                <span>{{ group.storeName }}</span>
              </div>

              <div class="flex items-start gap-4">
                <img :src="group.image" :alt="group.productName"
                  class="w-16 h-16 rounded object-cover border border-slate-100 shrink-0" />
                <div class="flex-1 min-w-0">
                  <h3 class="text-xs font-bold text-slate-800 truncate">{{ group.productName }}</h3>
                  <p class="text-[11px] text-slate-400 mt-0.5">{{ group.variant }}</p>
                  <p class="text-xs text-slate-500 mt-2">{{ group.qty }} x {{ formatCurrency(group.price) }}</p>
                </div>
                <div class="text-right font-bold text-xs text-slate-800">
                  {{ formatCurrency(group.price * group.qty) }}
                </div>
              </div>

              <div class="bg-slate-50/80 rounded p-3 border border-slate-100 space-y-1.5">
                <label class="text-[11px] text-slate-500 block">Pilih Pengiriman</label>
                <Select v-model="group.selectedShipping" :options="shippingOptions" optionLabel="label"
                  optionValue="value" class="w-full text-xs! bg-white! rounded-lg!" />
              </div>
            </div>
          </div>

        </div>

        <!-- KOLOM KANAN (Metode Pembayaran + Ringkasan Biaya) -->
        <div class="lg:col-span-5 space-y-6">

          <!-- Card 1: Metode Pembayaran -->
          <div class="bg-white rounded p-6 shadow-sm border border-slate-100 space-y-4">
            <div class="flex items-center gap-2 font-bold text-slate-800 text-sm">
              <i class="pi pi-credit-card text-blue-600"></i>
              <h2>Metode Pembayaran</h2>
            </div>

            <div class="bg-blue-50/60 rounded p-4 border border-blue-100 space-y-3">
              <div class="flex items-center gap-2 text-xs font-bold text-blue-700">
                <i class="pi pi-info-circle text-blue-600"></i>
                <span>Transfer Bank Manual</span>
              </div>
              <p class="text-[11px] text-slate-600 leading-relaxed">
                Silakan transfer sesuai dengan total tagihan ke rekening berikut:
              </p>

              <div class="bg-white rounded p-3 border border-blue-100 flex items-center justify-between">
                <div>
                  <span class="text-[10px] text-slate-400 uppercase font-semibold block">{{ paymentInfo.bankName
                  }}</span>
                  <span class="text-sm font-bold text-slate-800 tracking-wide">{{ paymentInfo.accountNumber }}</span>
                  <span class="text-[11px] text-slate-500 block mt-0.5">a.n. {{ paymentInfo.accountHolder }}</span>
                </div>
                <button @click="copyAccountNumber"
                  class="text-xs text-blue-600 font-semibold flex items-center gap-1 hover:underline">
                  <i :class="[isCopied ? 'pi pi-check' : 'pi pi-copy', 'text-xs']"></i>
                  <span>{{ isCopied ? 'Tersalin' : 'Salin' }}</span>
                </button>
              </div>

              <input ref="fileInput" type="file" accept="image/*" class="hidden" @change="handleFileSelect" />

              <!-- Simulasi Upload Area -->
              <div v-if="!previewImage && !isUploading" @click="triggerFileInput" @dragover.prevent
                @drop.prevent="handleDrop"
                class="border-2 border-dashed border-blue-200 hover:border-blue-500 rounded p-5 bg-white flex flex-col items-center justify-center cursor-pointer transition-colors group">
                <div
                  class="w-10 h-10 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                  <i class="pi pi-cloud-upload text-lg"></i>
                </div>
                <p class="text-xs font-semibold text-slate-700">Unggah Bukti Transfer</p>
                <p class="text-[10px] text-slate-400 mt-1">Klik atau seret gambar ke sini (.PNG, .JPG)</p>
              </div>

              <div v-else-if="isUploading" class="border border-blue-100 rounded p-4 bg-white space-y-2">
                <div class="flex items-center justify-between text-xs text-slate-600 font-medium">
                  <span class="flex items-center gap-2">
                    <i class="pi pi-spin pi-spinner text-blue-600"></i>
                    Mengunggah gambar...
                  </span>
                  <span>{{ uploadProgress }}%</span>
                </div>
                <div class="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                  <div class="bg-blue-600 h-1.5 transition-all duration-200" :style="{ width: uploadProgress + '%' }">
                  </div>
                </div>
              </div>

              <div v-else-if="isSuccess && previewImage" class="space-y-2">
                <div class="relative border border-slate-200 rounded overflow-hidden bg-white group">
                  <img :src="previewImage" alt="Bukti Transfer" class="w-full h-36 object-cover" />
                  <div
                    class="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <button @click="triggerFileInput"
                      class="bg-white text-slate-800 text-xs px-3 py-1.5 rounded-lg font-semibold hover:bg-slate-100">
                      Ganti
                    </button>
                    <button @click="removeImage"
                      class="bg-rose-600 text-white text-xs px-3 py-1.5 rounded-lg font-semibold hover:bg-rose-700">
                      Hapus
                    </button>
                  </div>
                </div>

                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-1.5 text-xs text-emerald-600 font-semibold">
                    <i class="pi pi-check-circle text-xs"></i>
                    <span>Berhasil diunggah</span>
                  </div>
                  <button @click="removeImage" class="text-[11px] text-rose-500 hover:underline">Hapus</button>
                </div>
              </div>

              <p class="text-[10px] text-slate-400 italic">
                *Pesanan akan diproses setelah bukti transfer dikonfirmasi oleh admin.
              </p>
            </div>
          </div>

          <!-- Card 2: Ringkasan Biaya -->
          <div class="bg-white rounded p-6 shadow-sm border border-slate-100 space-y-4">
            <h2 class="font-bold text-slate-800 text-sm">Ringkasan Biaya</h2>

            <div class="space-y-2 text-xs border-b border-slate-100 pb-4">
              <div class="flex items-center justify-between text-slate-600">
                <span>Total Harga (3 barang)</span>
                <span class="font-medium text-slate-800">{{ formatCurrency(totalItemsPrice) }}</span>
              </div>
              <div class="flex items-center justify-between text-slate-600">
                <span>Total Ongkos Kirim</span>
                <span class="font-medium text-slate-800">{{ formatCurrency(totalShippingCost) }}</span>
              </div>
              <div class="flex items-center justify-between text-slate-600">
                <span>Biaya Layanan</span>
                <span class="font-medium text-slate-800">{{ formatCurrency(serviceFee) }}</span>
              </div>
            </div>

            <div class="flex items-center justify-between pt-1">
              <span class="text-xs font-bold text-slate-800">Total Tagihan</span>
              <span class="text-lg font-bold text-blue-600">{{ formatCurrency(grandTotal) }}</span>
            </div>

            <Button label="Buat Pesanan" :disabled="!isSuccess || isSubmittingOrder" :loading="isSubmittingOrder"
              @click="handleCreateOrder"
              class="w-full bg-blue-600! border-blue-600! py-3! text-xs! font-bold! rounded! shadow-sm! hover:bg-blue-700! disabled:opacity-50! disabled:cursor-not-allowed!" />
          </div>

        </div>

      </div>

    </div>

    <!-- DIALOG / MODAL PILIH & UBAH ALAMAT -->
    <Dialog v-model:visible="isAddressModalOpen" modal header="Pilih Alamat Pengiriman"
      :style="{ width: '90%', maxWidth: '540px' }" class="rounded!">
      <div class="space-y-4 py-2">
        <div v-if="!isAddNewFormOpen" class="space-y-3 max-h-80 overflow-y-auto pr-1">
          <div v-for="addr in addresses" :key="addr.id" @click="selectAddress(addr.id)" :class="[
            'p-4 rounded border text-xs cursor-pointer transition-all space-y-1',
            selectedAddressId === addr.id
              ? 'border-blue-600 bg-blue-50/40 ring-2 ring-blue-500/20'
              : 'border-slate-200 hover:border-slate-300'
          ]">
            <div class="flex items-center justify-between font-bold text-slate-800">
              <div class="flex items-center gap-2">
                <span>{{ addr.name }}</span>
                <span v-if="addr.isPrimary"
                  class="bg-blue-100 text-blue-700 text-[10px] px-2 py-0.5 rounded-full font-semibold">Utama</span>
              </div>
              <i v-if="selectedAddressId === addr.id" class="pi pi-check-circle text-blue-600 text-sm"></i>
            </div>
            <p class="text-slate-500">{{ addr.phone }}</p>
            <p class="text-slate-600 leading-relaxed mt-1">{{ addr.fullAddress }}</p>
          </div>

          <Button label="Tambah Alamat Baru" icon="pi pi-plus" severity="secondary" outlined
            class="w-full text-xs! py-2.5! rounded! border-slate-300!" @click="isAddNewFormOpen = true" />
        </div>

        <div v-else class="space-y-3">
          <div class="space-y-1">
            <label class="text-xs font-semibold text-slate-700">Nama Penerima</label>
            <InputText v-model="newAddress.name" placeholder="mis. Budi Santoso" class="w-full text-xs! rounded!" />
          </div>

          <div class="space-y-1">
            <label class="text-xs font-semibold text-slate-700">Nomor Telepon</label>
            <InputText v-model="newAddress.phone" placeholder="mis. 081234567890" class="w-full text-xs! rounded!" />
          </div>

          <div class="space-y-1">
            <label class="text-xs font-semibold text-slate-700">Alamat Lengkap</label>
            <Textarea v-model="newAddress.fullAddress" rows="3"
              placeholder="Jalan, No. Rumah, RT/RW, Kecamatan, Kota, Kode Pos" class="w-full text-xs! rounded!" />
          </div>

          <div class="flex gap-2 pt-2">
            <Button label="Batal" severity="secondary" outlined class="flex-1 text-xs! py-2! rounded!"
              @click="isAddNewFormOpen = false" />
            <Button label="Simpan & Gunakan" class="flex-1 bg-blue-600! border-blue-600! text-xs! py-2! rounded!"
              @click="saveNewAddress" />
          </div>
        </div>
      </div>
    </Dialog>

    <!-- POPUP MODAL SUKSES PESANAN (MOCKUP GAMBAR) -->
    <Dialog v-model:visible="isSuccessModalOpen" modal :closable="false" :style="{ width: '90%', maxWidth: '480px' }"
      class="rounded-3xl! overflow-hidden">
      <div class="py-6 px-2 text-center space-y-6">

        <!-- Animated / Green Circle Check Icon -->
        <div class="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center mx-auto">
          <div class="w-14 h-14 rounded-full bg-emerald-400 text-white flex items-center justify-center shadow-sm">
            <i class="pi pi-check text-2xl font-bold"></i>
          </div>
        </div>

        <!-- Title & Subtitle -->
        <div class="space-y-2">
          <h2 class="text-lg font-extrabold text-slate-800">Pesanan Anda Telah Dibuat!</h2>
          <p class="text-xs text-slate-500 w-full mx-auto leading-relaxed">
            Terima kasih telah berbelanja di Kabita. Pesanan Anda sedang menunggu verifikasi pembayaran oleh admin.
          </p>
        </div>

        <!-- Info Card Banner -->
        <div class="bg-indigo-50/70 border border-indigo-100/80 rounded p-4 flex items-start gap-3 text-left">
          <div class="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center shrink-0 mt-0.5">
            <i class="pi pi-info-circle text-xs"></i>
          </div>
          <p class="text-[11px] text-slate-600 leading-relaxed">
            Estimasi verifikasi 1×24 jam. Pastikan Anda telah mengunggah bukti bayar pada halaman detail pesanan.
          </p>
        </div>

        <!-- Summary Specs Card -->
        <div class="bg-slate-50/80 border border-slate-100 rounded p-4 grid grid-cols-3 gap-2 text-left">
          <div>
            <span class="text-[10px] text-slate-400 block mb-1">Nomor Pesanan</span>
            <span class="text-xs font-bold text-slate-800 tracking-tight">{{ createdOrderData.orderNumber }}</span>
          </div>
          <div>
            <span class="text-[10px] text-slate-400 block mb-1">Total Pembayaran</span>
            <span class="text-xs font-bold text-blue-600">{{ formatCurrency(createdOrderData.totalAmount) }}</span>
          </div>
          <div>
            <span class="text-[10px] text-slate-400 block mb-1">Metode Pembayaran</span>
            <span class="text-xs font-bold text-slate-800 leading-tight block">{{ createdOrderData.paymentMethod
            }}</span>
          </div>
        </div>

        <!-- Bottom Action Buttons -->
        <div class="flex flex-col sm:flex-row gap-3 pt-2">
          <Button label="Lihat Detail Pesanan" icon="pi pi-file"
            class="flex-1 bg-blue-600! border-blue-600! text-xs! py-3! rounded! font-bold!" @click="navigateToOrders" />
          <Button label="Kembali ke Beranda" severity="secondary" outlined
            class="flex-1 text-xs! py-3! rounded! font-bold! border-slate-300! text-blue-600! hover:bg-slate-50!"
            @click="navigateToHome" />
        </div>

      </div>
    </Dialog>

  </div>
</template>