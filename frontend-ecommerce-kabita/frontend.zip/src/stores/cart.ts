import type { CartItem, Product } from '@/types'
import { defineStore } from 'pinia'
import { computed, ref } from 'vue'

// Price string × qty → string (konsisten dengan format Laravel)
function calcSubtotal(price: string, quantity: number): string {
  return String(Number(price) * quantity)
}

export const useCartStore = defineStore('cart', () => {
  const items = ref<CartItem[]>([])

  const totalItems = computed(() => items.value.reduce((sum, i) => sum + i.quantity, 0))
  const totalPrice = computed(() => items.value.reduce((sum, i) => sum + Number(i.subtotal), 0))

  function addToCart(product: Product, quantity = 1) {
    const found = items.value.find((i) => i.product_id === product.id)
    if (found) {
      found.quantity += quantity
      found.subtotal = calcSubtotal(product.price, found.quantity)
    } else {
      items.value.push({
        id: Date.now(), // ID sementara untuk mock
        cart_id: 1,
        product_id: product.id,
        quantity,
        subtotal: calcSubtotal(product.price, quantity),
        product,
        shop: product.shop,
        created_at: null,
        updated_at: null,
      })
    }
    // TODO(api): axios.post('/cart/items', { product_id: product.id, quantity } satisfies AddToCartRequest)
  }

  return { items, totalItems, totalPrice, addToCart }
})