import { defineStore } from 'pinia';
import { computed, ref } from 'vue';
import { useRouter } from 'vue-router';
import { authService } from '../services/authService';
import type { LoginRequest, RegisterRequest, User } from '../types';

export const useAuthStore = defineStore('auth', () => {
  const router = useRouter();
  const user = ref<User | null>(null);
  const token = ref<string | null>(localStorage.getItem('token'));

  const isAuthenticated = computed(() => !!token.value);
  const userRole = computed(() => user.value?.role);
  const isEmailVerified = computed(() => !!user.value?.email_verified_at);

  async function login(credentials: LoginRequest) {
    const response = await authService.login(credentials);
    
    if (response.success && response.data) {
      user.value = response.data.user;
      token.value = response.data.token;
      localStorage.setItem('token', response.data.token);
      
      // Redirect berdasarkan role
      if (user.value.role === 'seller') {
        router.push('/seller/dashboard');
      } else {
        router.push('/');
      }
    }
    
    return response;
  }

  async function register(data: RegisterRequest) {
    const response = await authService.register(data);
    
    if (response.success && response.data) {
      user.value = response.data.user;
      // Tidak set token karena user belum verified
    }
    
    return response;
  }

  async function verifyEmail(email: string, code: string) {
    const response = await authService.verifyEmail({ email, code });
    
    if (response.success) {
      // Auto login setelah verify
      await login({ email, password: '' }); // Password tidak diperlukan karena sudah verified
    }
    
    return response;
  }

  async function resendCode(email: string) {
    return await authService.resendVerificationCode(email);
  }

  async function logout() {
    if (token.value) {
      await authService.logout();
    }
    
    user.value = null;
    token.value = null;
    localStorage.removeItem('token');
    router.push('/login');
  }

  async function fetchUser() {
    if (!token.value) return;
    
    try {
      const response = await authService.getCurrentUser();
      if (response.success && response.data) {
        user.value = response.data as User;
      }
    } catch (error) {
      console.error('Failed to fetch user:', error);
      await logout();
    }
  }

  return {
    user,
    token,
    isAuthenticated,
    userRole,
    isEmailVerified,
    login,
    register,
    verifyEmail,
    resendCode,
    logout,
    fetchUser,
  };
});