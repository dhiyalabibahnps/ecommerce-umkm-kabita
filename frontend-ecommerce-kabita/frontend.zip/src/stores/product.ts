import type { Category, Product, Shop } from '@/types'
import { defineStore } from 'pinia'
import { computed, ref } from 'vue'

function mockShop(id: number, name: string, slug: string): Shop {
  return {
    id,
    seller_id: id + 100,
    name,
    slug,
    description: null,
    logo: null,
    status: 'verified',
    verified_by: 1,
    verified_at: null,
    rejection_reason: null,
    created_at: '2026-06-01T00:00:00Z',
    updated_at: '2026-06-01T00:00:00Z',
  }
}

function mockCategory(id: number, name: string, slug: string, icon: string): Category {
  return {
    id,
    name,
    slug,
    icon,
    product_count: null,
    created_at: '2026-06-01T00:00:00Z',
  }
}

type ProductSeed = Pick<Product, 'id' | 'shop_id' | 'category_id' | 'name' | 'slug' | 'price' | 'stock'> & Partial<Product>
function mockProduct(seed: ProductSeed): Product {
  return {
    description: null,
    cost_price: null,
    weight: null,
    status: 'active',
    verified_at: null,
    rejection_reason: null,
    created_at: '2026-07-01T00:00:00Z',
    images: [],
    ...seed,
  }
}

export const useProductStore = defineStore('product', () => {
  const products = ref<Product[]>([
    mockProduct({
      id: 1,
      shop_id: 1,
      category_id: 1,
      name: 'Kopi Arabika Gayo',
      slug: 'kopi-arabika-gayo',
      price: '100000',
      stock: 28,
      shop: mockShop(1, 'Gayo Roastery', 'gayo-roastery'),
      category: mockCategory(1, 'Makanan', 'makanan', 'pi pi-utensils'),
      images: [{ id: 1, url: 'https://www.figma.com/api/mcp/asset/19155f17-6428-4818-8d8c-18fc625c312c.png' }],
    }),
    mockProduct({
      id: 2,
      shop_id: 2,
      category_id: 4,
      name: 'Mug Keramik Estetik',
      slug: 'mug-keramik-estetik',
      price: '85000',
      stock: 18,
      shop: mockShop(2, 'Studio Keramik', 'studio-keramik'),
      category: mockCategory(4, 'Perabot', 'perabot', 'pi pi-home'),
      images: [{ id: 2, url: 'https://www.figma.com/api/mcp/asset/71427f65-9e63-4463-97e7-43c53cbde5bf.png' }],
    }),
    mockProduct({
      id: 3,
      shop_id: 3,
      category_id: 4,
      name: 'Keranjang Rotan Serbaguna',
      slug: 'keranjang-rotan-serbaguna',
      price: '150000',
      stock: 12,
      shop: mockShop(3, 'Anyaman Lokal', 'anyaman-lokal'),
      category: mockCategory(4, 'Perabot', 'perabot', 'pi pi-home'),
      images: [{ id: 3, url: 'https://www.figma.com/api/mcp/asset/82280461-a1c9-43e2-a356-5654dd557d2b.png' }],
    }),
    mockProduct({
      id: 4,
      shop_id: 4,
      category_id: 1,
      name: 'Madu Murni Organik 500ml',
      slug: 'madu-murni-organik-500ml',
      price: '90000',
      stock: 45,
      shop: mockShop(4, 'Peternak Lebah', 'peternak-lebah'),
      category: mockCategory(1, 'Makanan', 'makanan', 'pi pi-utensils'),
      images: [{ id: 4, url: 'https://www.figma.com/api/mcp/asset/2d4011da-ff35-4cd1-88ba-e6318c4baab0.png' }],
    }),
    mockProduct({
      id: 5,
      shop_id: 5,
      category_id: 4,
      name: 'Talenan Kayu Jati Solid',
      slug: 'talenan-kayu-jati-solid',
      price: '120000',
      stock: 20,
      shop: mockShop(5, 'Kerajinan Kayu', 'kerajinan-kayu'),
      category: mockCategory(4, 'Perabot', 'perabot', 'pi pi-home'),
      images: [{ id: 5, url: 'https://www.figma.com/api/mcp/asset/75c9adf7-2ae4-4cea-ba03-fad6aa87ccda.png' }],
    }),
    mockProduct({
      id: 6,
      shop_id: 6,
      category_id: 6,
      name: 'Sandal Kulit Tenun',
      slug: 'sandal-kulit-tenun',
      price: '135000',
      stock: 22,
      shop: mockShop(6, 'Kerajinan Kaki', 'kerajinan-kaki'),
      category: mockCategory(6, 'Hobi', 'hobi', 'pi pi-gift'),
      images: [{ id: 6, url: 'https://placehold.co/400x300/bf9a6a/ffffff?text=Sandal+Kulit' }],
    }),
    mockProduct({
      id: 7,
      shop_id: 7,
      category_id: 2,
      name: 'Kamera Mirrorless Pro X-T5 Body Only - Black Edition',
      slug: 'kamera-mirrorless-pro-x-t5-body-only-black-edition',
      price: '25500000',
      stock: 15,
      description:
        'Kamera mirrorless flagship terbaru dengan sensor APS-C 40.2MP X-Trans CMOS 5 HR. Menawarkan performa tinggi untuk fotografi dan videografi profesional.',
      shop: mockShop(7, 'DigiCam Official', 'digicam-official'),
      category: mockCategory(2, 'Elektronik', 'elektronik', 'pi pi-camera'),
      images: [
        {
          id: 7,
          url: 'https://www.figma.com/api/mcp/asset/0214cf93-0c6a-41a4-a5c7-e8b2a2e757ee.png',
        },
        {
          id: 8,
          url: 'https://www.figma.com/api/mcp/asset/3c4132a0-8795-4ba1-b2c0-052abd35ab5f.png',
        },
        {
          id: 9,
          url: 'https://www.figma.com/api/mcp/asset/eb3496c0-7724-4a6c-87dc-e47e3ebedd59.png',
        },
        {
          id: 10,
          url: 'https://www.figma.com/api/mcp/asset/d8a03924-2b8d-4051-8797-015a83207ff2.png',
        },
      ],
    }),
  ])

  const activeProducts = computed(() => products.value.filter((product) => product.status === 'active'))
  const featuredProducts = computed(() => activeProducts.value.slice(0, 6))

  return { products, activeProducts, featuredProducts }
})
