<script setup lang="ts">
import ProductGrid from '@/components/home/ProductGrid.vue';
import { useProductStore } from '@/stores/product';

const productStore = useProductStore()
</script>

<template>
  <section class="container max-w-screen-xl mx-auto px-4">
    <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between mb-6">
      <div>
        <h2 class="text-2xl font-bold text-slate-950">Semua Produk</h2>
        <p class="text-sm text-slate-500">Temukan pilihan produk UMKM spesial hari ini.</p>
      </div>
      <router-link to="/produk" class="text-sky-600 font-semibold no-underline hover:text-sky-700">Lihat
        Semua</router-link>
    </div>

    <ProductGrid :products="productStore.featuredProducts.slice(0, 5)" />
  </section>
</template>
