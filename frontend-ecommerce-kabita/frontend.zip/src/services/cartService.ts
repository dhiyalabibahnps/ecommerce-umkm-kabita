import type { AddToCartRequest, Cart, UpdateCartItemRequest } from '../types';
import apiClient from './apiClient';

export const cartService = {
  async get(): Promise<Cart> {
    const response = await apiClient.get('/cart');
    return response.data.data;
  },

  async addItem(data: AddToCartRequest): Promise<Cart> {
    const response = await apiClient.post('/cart/items', data);
    return response.data.data;
  },

  async updateItem(cartItemId: number, data: UpdateCartItemRequest): Promise<Cart> {
    const response = await apiClient.put(`/cart/items/${cartItemId}`, data);
    return response.data.data;
  },

  async removeItem(cartItemId: number): Promise<Cart> {
    const response = await apiClient.delete(`/cart/items/${cartItemId}`);
    return response.data.data;
  },

  async clear(): Promise<Cart> {
    const response = await apiClient.delete('/cart/clear');
    return response.data.data;
  },
};
