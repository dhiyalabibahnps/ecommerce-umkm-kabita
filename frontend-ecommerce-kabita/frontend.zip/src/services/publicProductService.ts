import type { PaginationMeta, Product } from '../types';
import apiClient from './apiClient';

export const publicProductService = {
  async list(filters?: {
    search?: string;
    category_id?: number;
    shop_id?: number;
    min_price?: number;
    max_price?: number;
    sort?: 'newest' | 'price_asc' | 'price_desc';
    per_page?: number;
  }): Promise<{ data: Product[]; meta: PaginationMeta }> {
    const response = await apiClient.get('/public/products', { params: filters });
    return { data: response.data.data, meta: response.data.meta };
  },

  async getBySlug(slug: string): Promise<Product> {
    const response = await apiClient.get(`/public/products/${slug}`);
    return response.data.data;
  },
};
