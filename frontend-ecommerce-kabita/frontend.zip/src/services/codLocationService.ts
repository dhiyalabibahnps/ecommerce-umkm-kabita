import type { CodLocation, StoreCodLocationRequest } from '../types';
import apiClient from './apiClient';

export const codLocationService = {
  async list(): Promise<CodLocation[]> {
    const response = await apiClient.get('/cod-locations');
    return response.data.data;
  },

  async create(data: StoreCodLocationRequest): Promise<CodLocation> {
    const response = await apiClient.post('/cod-locations', data);
    return response.data.data;
  },

  async update(codLocationId: number, data: StoreCodLocationRequest): Promise<CodLocation> {
    const response = await apiClient.put(`/cod-locations/${codLocationId}`, data);
    return response.data.data;
  },

  async delete(codLocationId: number): Promise<void> {
    await apiClient.delete(`/cod-locations/${codLocationId}`);
  },
};
