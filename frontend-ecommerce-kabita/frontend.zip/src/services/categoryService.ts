import type { Category, CreateCategoryRequest, UpdateCategoryRequest } from '../types';
import apiClient from './apiClient';

export const categoryService = {
  async list(): Promise<Category[]> {
    const response = await apiClient.get('/categories');
    return response.data.data;
  },

  async getBySlug(slug: string): Promise<Category> {
    const response = await apiClient.get(`/categories/${slug}`);
    return response.data.data;
  },

  async create(data: CreateCategoryRequest): Promise<Category> {
    const response = await apiClient.post('/categories', data);
    return response.data.data;
  },

  async update(slug: string, data: UpdateCategoryRequest): Promise<Category> {
    const response = await apiClient.put(`/categories/${slug}`, data);
    return response.data.data;
  },

  async delete(slug: string): Promise<void> {
    await apiClient.delete(`/categories/${slug}`);
  },
};
