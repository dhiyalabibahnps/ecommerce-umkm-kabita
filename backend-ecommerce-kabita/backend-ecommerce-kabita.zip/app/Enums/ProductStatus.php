<?php

declare(strict_types=1);

namespace App\Enums;

enum ProductStatus: string
{
    case PENDING = 'pending';
    case APPROVED = 'approved';
    case REJECTED = 'rejected';
}
